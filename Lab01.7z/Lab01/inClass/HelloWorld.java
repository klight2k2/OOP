// examle 1

public class HelloWorld {
    public static void main(String arg[]) {
        System.out.println("Xin chao \n cac ban!");
        System.out.println("Hello \t world!");
    }
}